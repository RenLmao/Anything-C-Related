#include <iostream>
#include <windows.h>
#include <wlanapi.h>
#include <objbase.h>
#include <wtypes.h>

#include <cstdio>
#include <string>
#include <cstdlib>
#include <vector>

HANDLE getOpenHandle();
PWLAN_INTERFACE_INFO_LIST getEnumInterfaces(HANDLE hClient);
std::string wchar2string(const wchar_t* str);
std::string getInterfaceState(PWLAN_INTERFACE_INFO &pIfInfo);

//todo
//oop that bitch
//enum for interface state
//select correct interface

int main() {
    std::cout << "Welcome to Wifi Cracker" << std::endl;
    std::cout << "Scanning for available wifi interfaces..." << std::endl;
    std::cout << '\n';
    HANDLE hClient = getOpenHandle();
    PWLAN_INTERFACE_INFO_LIST pIfList = getEnumInterfaces(hClient);
    PWLAN_INTERFACE_INFO pIfInfo = NULL;

    //PWLAN_AVAILABLE_NETWORK_LIST pBssList = NULL;
    //WlanGetAvailableNetworkList(hClient, pIfList, 0, NULL, &pBssList);

    WCHAR GuidString[39] = { 0 };

    std::cout << pIfList->dwNumberOfItems << " interface(s) have been found" << std::endl;
    for (int i = 0; i < pIfList->dwNumberOfItems; i++) {
        pIfInfo = (WLAN_INTERFACE_INFO *) &pIfList->InterfaceInfo[i];

        //wtf is happening?
        int ret = StringFromGUID2(pIfInfo->InterfaceGuid, (LPOLESTR) & GuidString,
                                  sizeof (GuidString) / sizeof (*GuidString));
        if (ret == 0) {
            std::cout << "StringFromGUID2 Failed!" << std::endl;
            std::exit(0);
        }
        std::cout << "id " << i << " : Found interface " << wchar2string(std::wstring(pIfInfo->strInterfaceDescription).c_str()) << " || Current state : " + getInterfaceState(pIfInfo) << std::endl;
    }

    std::string interfaceName = wchar2string(std::wstring(pIfInfo->strInterfaceDescription).c_str());

    PWLAN_AVAILABLE_NETWORK_LIST pBssList = NULL;
    PWLAN_AVAILABLE_NETWORK pBssEntry = NULL;

    DWORD result = WlanGetAvailableNetworkList(hClient, &pIfInfo->InterfaceGuid, 0x00000003, NULL, &pBssList);
    if (result != ERROR_SUCCESS) {
            wprintf(L"WlanGetAvailableNetworkList failed with error: %u\n",
                result);
        std::exit(0);
    }

    std::cout << "Found " << pBssList->dwNumberOfItems << " networks on interface " << interfaceName << std::endl;

    std::vector<WLAN_AVAILABLE_NETWORK*> networks;

    for (int i = 0, id = 0; i < pBssList->dwNumberOfItems; i++) {
        pBssEntry = (WLAN_AVAILABLE_NETWORK *) &pBssList->Network[i];

        //Check if the network is an actual network and has a name
        if (wchar2string(std::wstring(pBssEntry->strProfileName).c_str()).empty()) continue;
        networks.push_back(pBssEntry);
        std::cout << "id " << id << " : Found network : " << wchar2string(std::wstring(pBssEntry->strProfileName).c_str()) << std::endl;
        id++;
    }

    std::cout << std::endl;
    int id = -1;
    while(id < 0 || id >= networks.size()) {
        std::cout << "Type id of desired network : " << std::endl;
        std::cin >> id;
    }

    pBssEntry = (WLAN_AVAILABLE_NETWORK *) networks[id];
    std::cout << "Selected network : " << wchar2string(std::wstring(pBssEntry->strProfileName).c_str());



    WlanFreeMemory(pBssList);
    WlanFreeMemory(pIfList);
    return 0;
}

HANDLE getOpenHandle() {
    DWORD result;
    DWORD  dwClientVersion;
    HANDLE hClient;
    result = WlanOpenHandle(2, NULL, &dwClientVersion, &hClient);

    if (result != ERROR_SUCCESS) {
        std::cout << "WlanOpenHandle failed!" << std::endl;
        std::exit(1);
    }
    return hClient;
}

PWLAN_INTERFACE_INFO_LIST getEnumInterfaces(HANDLE hClient) {
    PWLAN_INTERFACE_INFO_LIST pIfList = NULL;
    DWORD result;

    result = WlanEnumInterfaces(hClient, NULL, &pIfList);
    if (result != ERROR_SUCCESS) {
        std::cout << "WlanEnumInterfaces failed!" << std::endl;
        std::exit(1);
    }
    return pIfList;
}

std::string wchar2string(const wchar_t* str)
{
    std::string mystring;
    while( *str )
        mystring += (char)*str++;
    return  mystring;
}

std::string getInterfaceState(PWLAN_INTERFACE_INFO &pIfInfo) {
    switch (pIfInfo->isState) {
        case wlan_interface_state_not_ready:
            return("Not ready\n");
        case wlan_interface_state_connected:
            return("Connected\n");
        case wlan_interface_state_ad_hoc_network_formed:
            return("First node in a ad hoc network\n");
        case wlan_interface_state_disconnecting:
            return("Disconnecting\n");
        case wlan_interface_state_disconnected:
            return("Not connected\n");
        case wlan_interface_state_associating:
            return("Attempting to associate with a network\n");
        case wlan_interface_state_discovering:
            return("Auto configuration is discovering settings for the network\n");
        case wlan_interface_state_authenticating:
            return("In process of authenticating\n");
        default:
            return("Unknown state");
    }
}
bool connect(HANDLE &hClient, WCHAR &guid,WLAN_AVAILABLE_NETWORK &pBssEntry, PWLAN_AVAILABLE_NETWORK &pBssList) {
    WLAN_CONNECTION_PARAMETERS params;
    params.wlanConnectionMode = wlan_connection_mode_profile;
    params.strProfile = pBssEntry.strProfileName;
    params.pDot11Ssid = &pBssEntry.dot11Ssid;
    params.pDesiredBssidList = ;

    WlanConnect(hClient, guid, wlan_interface_state_connected, NULL);
}

