# Chess-ai-real-
With my last 2 braincells I used stackoverflow and i frankensteined this together, barely works off of hopes and dreams lmao

# Real Stuff
PeepeeChess is UCI chess engine based off of C++ and prayers.
