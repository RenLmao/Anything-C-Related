

#ifndef DATA_H_
#define DATA_H_

#include "general/types.h"
#include "general/wdl_score.h"
#include "board.h"
#include <vector>
#include <string>

struct Game{
  Board board;
  std::vector<Move> moves;
  WDLScore result;
  void forward() {
    if (board.get_num_made_moves() < moves.size()) {
      board.Make(moves[board.get_num_made_moves()]);
    }
  }
  void set_to_position_after(size_t move) {
    while (move > board.get_num_made_moves()) {
      board.Make(moves[board.get_num_made_moves()]);
    }
    while (move < board.get_num_made_moves()) {
      board.UnMake();
    }
  }
};

namespace data {

std::vector<Game> LoadGames(size_t max_games = 1200000, std::string game_file = "data/CCRL.ucig");
void SaveBoardFens(std::string filename, std::vector<Board> boards);
std::vector<Board> LoadBoardFens(std::string filename = "data/sample_evals.fen");

void SetGameToRandom(Game &game);
void SetGamesToRandom(std::vector<Game> &games);
bool SetGameToRandomQuiescent(Game &game);
void SetGamesToRandomQuiescent(std::vector<Game> &games);

}

#endif /* DATA_H_ */
