

#ifndef UCI_H_
#define UCI_H_

#include <string>

namespace uci{

//Runs the UCI protocol until the client exits
void Loop();
void Info(std::string message);

}

#endif /* UCI_H_ */
