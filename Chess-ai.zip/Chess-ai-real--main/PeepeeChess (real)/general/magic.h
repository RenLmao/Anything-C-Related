

#ifndef GENERAL_MAGIC_H_
#define GENERAL_MAGIC_H_

#include "types.h"

namespace magic {

template<PieceType pt>
BitBoard GetAttackMap(const int &index, BitBoard AllPieces);
BitBoard GetAttackVectors(BitBoard src, BitBoard des);
BitBoard GetAttackMap(PieceType piece_type, Square square, BitBoard all_pieces);
int GetSquareDistance(const Square a, const Square b);
BitBoard GetKingArea(const Square square);
BitBoard GetSquareFile(const Square square);

}

#endif /* GENERAL_MAGIC_H_ */
