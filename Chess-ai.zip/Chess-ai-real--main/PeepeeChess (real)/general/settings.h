

#ifndef GENERAL_SETTINGS_H_
#define GENERAL_SETTINGS_H_

#include "types.h"
#include <string>

namespace settings {

const std::string engine_name = "Peepee Engine";
const std::string engine_version = "69";

const std::string engine_author = "Me";

#if defined(__BMI2__)
const std::string compile_arch = "BMI2";
#elif defined(__AVX__)
const std::string compile_arch = "AVX";
#elif defined(__SSE4_2__)
const std::string compile_arch = "SSE4.2";
#elif defined(__SSE4_1__)
const std::string compile_arch = "SSE4.1";
#else
const std::string compile_arch = "";
#endif

const std::string kSearchParamPath = "search_params/";
const std::string kSearchParamVersionExtension = "190516";

const std::string kSearchParamFile = kSearchParamPath + "sparams"
    + kSearchParamVersionExtension + ".txt";
const std::string kSearchParamExplanationFile = kSearchParamFile + ".info";

const std::string kSearchParamInCheckFile = kSearchParamPath + "sparams_in_check"
    + kSearchParamVersionExtension + ".txt";
const std::string kSearchParamInCheckExplanationFile = kSearchParamInCheckFile + ".info";

const std::string kCCRLPath = "data/CCRL.ucig";
const std::string kCEGTPath = "data/CEGT.ucig";

const bool kTrainFromScratch = false;

const bool kUseExtensions = true;
const bool kUseScoreBasedPruning = true;
const bool kUseNullMoves = true && kUseExtensions;
const Depth kRepsForDraw = 2;
const Depth kMaxDepth = 128;
const Depth kSingularExtensionDepth = 9;

const bool kUseQS = true;

}

#endif /* GENERAL_SETTINGS_H_ */
