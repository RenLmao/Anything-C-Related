

#include <iostream>

#include "benchmark.h"
#include "transposition.h"
#include "uci.h"
#include "general/types.h"
#include "learning/linear_algebra.h"
#include "general/magic.h"
#include "general/settings.h"
#include "board.h"
#include "search.h"

#include "net_evaluation.h"

bool Equals(std::string string_a, std::string string_b) {
  return string_a.compare(string_b) == 0;
}

int main(int argc, char **argv) {
  table::SetTableSize(32);

  search::LoadSearchVariablesHardCoded();
  net_evaluation::init_weights();

  if (argc > 1 && Equals(argv[1], "bench")) {
    benchmark::RunBenchCommand(argc, argv);
    return 0;
  }


  uci::Loop();
  return 0;
}
