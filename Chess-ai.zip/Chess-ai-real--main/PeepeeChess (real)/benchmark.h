
#ifndef BENCHMARK_H_
#define BENCHMARK_H_

#include "general/types.h"

namespace benchmark {

int TimeToDepthSuite();
double EntropyLossTimedSuite(Milliseconds time_per_position);
void PerftSuite(std::string filename);
void PerftSuite();
void SymmetrySuite();
double ZuriChessDatasetLoss();

void RunBenchCommand(int argc, char **argv);

}

#endif /* BENCHMARK_H_ */
