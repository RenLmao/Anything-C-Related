

#ifndef NET_EVALUATION_H_
#define NET_EVALUATION_H_

#include "general/types.h"
#include "general/settings.h"
#include "board.h"
#include <vector>

namespace net_evaluation {

Score ScoreBoard(const Board &board);
// Returns the input features for the net for a specific board position.
// In the future this may become more complicated, depending on how pieces get encoded.
std::vector<int32_t> GetNetInputs(const Board &board);
void init_weights();

void SetContempt(Color color, int32_t value);
std::array<Score, 2> GetDrawArray();

Score AddContempt(Score score, Color color);
Score RemoveContempt(Score score, Color color);
}

#endif /* NET_EVALUATION_H_ */
