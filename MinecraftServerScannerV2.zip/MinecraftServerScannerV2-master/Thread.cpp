//
// Created by Hypericats on 2/20/2024.
//

#include "Thread.hpp"

//Default minecraft port
const static unsigned short port = 25565;

void Thread::operator()(AddressManager addrManager) {
    while (true) {
        ipAddress addr = addrManager.getNextJob();
        scan(&addr);
    }
}

void Thread::scan(ipAddress *address) {
    Util::loopPrint("Scanning " + address->getString());
    ConnectionManager con(address, port);
    std::vector<char> packet = con.getHandshakePacket();
    con.ping(packet);

}



