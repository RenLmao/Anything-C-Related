//
// Created by Hypericats on 2/20/2024.
//

#include <string>
#include <vector>
#include "Util.hpp"

#ifndef MINECRAFTSERVERSCANNER_IPADDRESS_H
#define MINECRAFTSERVERSCANNER_IPADDRESS_H


class ipAddress {
private:
    unsigned char ipArray[4] {};

public:
    explicit ipAddress(const unsigned char addresses[4]): ipArray(*addresses) {};
    explicit ipAddress(std::string address);
    ipAddress(unsigned char val0, unsigned char val1, unsigned char val2, unsigned char val3);
    ipAddress();

    unsigned char get(char index);
    void set(unsigned char value, char index);
    std::string getString();
    void increment();
    ipAddress clone();
};


#endif //MINECRAFTSERVERSCANNER_IPADDRESS_H
