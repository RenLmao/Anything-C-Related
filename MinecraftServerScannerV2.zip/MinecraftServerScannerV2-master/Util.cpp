//
// Created by Hypericats on 2/20/2024.
//

#include "Util.hpp"

void Util::print(const std::string& str) {
    std::cout << str << std::endl;
}

void Util::loopPrint(const std::string& str) {
    std::cout << str << "\n";
}

std::string Util::getInput() {
    std::string in;
    std::getline(std::cin, in);
    return in;
}

std::string Util::getInput(const std::string& prompt) {
    std::cout << prompt << '\n';
    std::string str = getInput();
    std::cout << std::endl;
    return str;
}

//If I need a string version in the future, str.find(std::basic_string, size_t size) exists
std::vector<std::string> Util::splitString(const std::string& str, const char& regex) {
    std::vector<std::string> splits;
    std::string strCopy = str;
    int searchIndex;
    int index = 0;
    //Check that there is still another instance of the regex in the string
    while(true) {
        searchIndex = (int) strCopy.find(regex);
        if (searchIndex == -1) break;
        //Need to store in variable in order to call the constructor from Cstring to string
        std::string out = strCopy.substr(0, searchIndex);
        splits.push_back(out);
        strCopy = strCopy.substr(searchIndex + 1);
        index ++;
    }
    splits.push_back(strCopy);
    return splits;
}

int Util::getAmountOf(const std::string& str, const char& regex) {
    int counter = 0;
    for (const char& c : str) {
        if (c == regex) counter++;
    }
    return counter;
}



/*
 *  unsigned char ipArray[4];
    int lastIndex = (int) str.find('.');
    ipArray[3] = std::stoi(str.substr(0, lastIndex - 1))
    lastIndex = (int) str.find('.');
    ipArray[2] = std::stoi(str.substr(0, lastIndex - 1))
    lastIndex = (int) str.find('.');
    ipArray[1] = std::stoi(str.substr(0, lastIndex - 1))
    lastIndex = (int) str.find('.');
    ipArray[0] = std::stoi(str.substr(0, lastIndex - 1))
 */