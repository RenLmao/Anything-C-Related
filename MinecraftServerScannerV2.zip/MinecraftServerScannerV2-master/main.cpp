#include "Util.hpp"
#include "ServerScanner.hpp"


int main() {
    ServerScanner::initScanner();

    return 0;
}
