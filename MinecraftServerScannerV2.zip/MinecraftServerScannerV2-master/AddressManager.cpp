//
// Created by Hypericats on 2/21/2024.
//

#include "AddressManager.hpp"

std::mutex _mutex;

static ipAddress* address;

ipAddress AddressManager::getNextJob() {
    //Lock the mutex or whatever so that only 1 thread can play with address
    std::unique_lock<std::mutex> lock(_mutex);
    ipAddress addr = *address;
    address->increment();
    return addr;
}

AddressManager::AddressManager(ipAddress *addr) {
    address = addr;
}
