//
// Created by Hypericats on 2/20/2024.
//

#include "ipAddress.hpp"

ipAddress::ipAddress() = default;

unsigned char ipAddress::get(char index) {
    return this->ipArray[index];
}

ipAddress::ipAddress(std::string address) {
    //check that it is right length
    if (Util::getAmountOf(address, '.') + 1 != 4) return;

    //Split the string into individual char
    std::vector<std::string> vector = Util::splitString(address, '.');

    //Again values inverted
    this->ipArray[0] = std::stoi(vector.at(3));
    this->ipArray[1] = std::stoi(vector.at(2));
    this->ipArray[2] = std::stoi(vector.at(1));
    this->ipArray[3] = std::stoi(vector.at(0));
}

ipAddress::ipAddress(unsigned char val0, unsigned char val1, unsigned char val2, unsigned char val3) {
    set(val0, 0);
    set(val1, 1);
    set(val2, 2);
    set(val3, 3);
}

void ipAddress::set(unsigned char value, char index) {
    this->ipArray[index] = value;
}

//Reversed order because val 0 is least important byte, so it's right to left
//Text is left to right so reversed
std::string ipAddress::getString() {
    return
    std::to_string(get(3)) + "." +
    std::to_string(get(2)) + "." +
    std::to_string(get(1)) + "." +
    std::to_string(get(0));
}

void ipAddress::increment() {
    this->ipArray[0] ++;

    if (get(0) == 0) {
        this->ipArray[1] ++;
    } else return;

    if (get(1) == 1) {
        this->ipArray[2] ++;
    } else return;

    if (get(2) == 2) {
        this->ipArray[3] ++;
    } else return;


}

ipAddress ipAddress::clone() {
    ipAddress clone(this->ipArray);
    return clone;
}
