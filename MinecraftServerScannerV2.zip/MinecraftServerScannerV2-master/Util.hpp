//
// Created by Hypericats on 2/20/2024.
//

#include <string>
#include <iostream>
#include <vector>

#ifndef MINERCRAFTSERVERSCANNER_UTIL_H
#define MINERCRAFTSERVERSCANNER_UTIL_H

class Util {
public:
    static void print(const std::string& str);
    static void loopPrint(const std::string& str);
    static std::vector<std::string> splitString(const std::string& str, const char& regex);
    static int getAmountOf(const std::string& str, const char& regex);
    static std::string getInput(const std::string& prompt);
    static std::string getInput();
};

#endif //MINERCRAFTSERVERSCANNER_UTIL_H