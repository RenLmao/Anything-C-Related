//
// Created by Hypericats on 2/21/2024.
//

#ifndef MINECRAFTSERVERSCANNER_ADDRESSMANAGER_HPP
#define MINECRAFTSERVERSCANNER_ADDRESSMANAGER_HPP


#include <mutex>

#include "ipAddress.hpp"

class AddressManager {
private:

public:
    static ipAddress getNextJob();

    explicit AddressManager(ipAddress* addr);
};


#endif //MINECRAFTSERVERSCANNER_ADDRESSMANAGER_HPP
