//
// Created by Hypericats on 2/20/2024.
//

#include <iostream>
#include <thread>
#include <vector>

#include "Util.hpp"
#include "ipAddress.hpp"
#include "Thread.hpp"
#include "AddressManager.hpp"

using namespace std;

#ifndef MINECRAFTSERVERSCANNER_SERVERSCANNER_H
#define MINECRAFTSERVERSCANNER_SERVERSCANNER_H


class ServerScanner {
private:
    static void end(ipAddress* address);
public:
    static void initScanner();
};


#endif //MINECRAFTSERVERSCANNER_SERVERSCANNER_H
