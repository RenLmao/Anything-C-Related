//
// Created by Hypericats on 2/20/2024.
//

#include "ServerScanner.hpp"

void ServerScanner::initScanner() {
    std::string strAddress = Util::getInput("Enter starting ip address :");
    ipAddress* address = new ipAddress(strAddress);
    Util::print("Selected starting ip address " + address->getString());
    std::string strThreadCount = Util::getInput("Enter thread count :");

    int threadCount;
    try {
        threadCount = std::stoi(strThreadCount);
    } catch (int threadCount) {
        threadCount = 5000;
    }
    Util::print("Creating " + to_string(threadCount) + " threads");

    vector<thread> threads;

    AddressManager addrManager(address);

    for (int i = 0; i < threadCount; i++) {
        threads.emplace_back(Thread(), addrManager);
    }

    //Should wait till all threads are done
    for (thread &thread : threads) {
        thread.join();
    }

    end(address);
}

void ServerScanner::end(ipAddress* address) {
    delete address;
}