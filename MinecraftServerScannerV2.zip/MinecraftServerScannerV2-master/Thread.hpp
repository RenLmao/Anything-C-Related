//
// Created by Hypericats on 2/20/2024.
//

#include <iostream>
#include <thread>
#include <vector>
#include <chrono>

#include "Util.hpp"
#include "AddressManager.hpp"
#include "ipAddress.hpp"
#include "ConnectionManager.hpp"

#ifndef MINECRAFTSERVERSCANNER_THREAD_H
#define MINECRAFTSERVERSCANNER_THREAD_H

//Create empty class to serverScanner so no include loop

class Thread {
private:
    void scan(ipAddress* address);
public:
    void operator()(AddressManager addrManager);
};

#endif //MINECRAFTSERVERSCANNER_THREAD_H