//
// Created by Hypericats on 2/21/2024.
//

#include <winsock.h>
#include "ConnectionManager.hpp"

ConnectionManager::ConnectionManager(ipAddress *address, unsigned short port) {
    this->address = address;
    this->port = port;
}


//Generate fake minecraft handshake packet, works correctly
std::vector<char> ConnectionManager::getHandshakePacket() {
    std::vector<char> packet;
    //Packet id
    packet.push_back(0x00);
    //Protocol Version
    writeInt(&packet, 765);
    //Server Address
    writeString(&packet, address->getString());
    //Port
    writeShort(&packet, this->port);
    //Next State (what is returned)
    writeInt(&packet, 1);
    return packet;
}

void ConnectionManager::writeInt(std::vector<char> *packet, unsigned int i) {
    while (true) {
        if ((i & 0xFFFFFF80) == 0) {
            packet->push_back(i);
            return;
        }
        packet->push_back(i & 0x7F | 0x80);
        i >>= 7;
    }
}

void ConnectionManager::writeString(std::vector<char> *packet, std::basic_string<char> str) {
    unsigned char buffer[str.length()];
    memcpy(buffer, str.data(), str.length());
    writeInt(packet, str.length());
    for (int i = 0; i < str.length(); i ++) {
        packet->push_back(buffer[i]);
    }
}

void ConnectionManager::writeShort(std::vector<char> *packet, unsigned short i) {
    packet->push_back((char) (i >> 8));
    packet->push_back((char) (i >> 0));
}

int ConnectionManager::readVarInt(const SOCKET* socket, ipAddress *address) {
    int i = 0;
    int j = 0;
    char buffer[1];
    while (true) {
        int n = recv(*socket, buffer, 1, 0);
        if (n < 0) {
            Util::loopPrint("Error reading int for ip " + address->getString());
            return -1;
        }
        int k = buffer[0];
        i |= (k & 0x7F) << j++ * 7;
        if ((k & 0x80) != 128) break;
    }
    return i;
}

void ConnectionManager::ping(std::vector<char> packet) {
    int n;
    struct hostent *server;
    struct sockaddr_in server_addr;

    WSADATA wsadata;
    n = WSAStartup(MAKEWORD(2,2), &wsadata);
    if (n != 0) {
        Util::loopPrint("Socket startup failed at " + address->getString());
        return;
    }

    struct addrinfo *result = NULL,
            *ptr = NULL,
            hints;

    ZeroMemory( &hints, sizeof(hints) );
    hints.ai_family   = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    hints.ai_family = AF_INET;

    SOCKET sock = INVALID_SOCKET;
    sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if (sock == INVALID_SOCKET) {
        printf("Error at socket(): %ld\n", WSAGetLastError());
        freeaddrinfo(result);
        WSACleanup();
        Util::loopPrint("Invalid socket " + address->getString());
        return;
    }

    SOCKADDR_IN ServerAddr;
    ServerAddr.sin_family = AF_INET;
    ServerAddr.sin_port = htons(port);
    ServerAddr.sin_addr.s_addr = inet_addr(address->getString().c_str());

    n = connect( sock, (SOCKADDR *) &ServerAddr, sizeof(ServerAddr));
    if (n == SOCKET_ERROR) {
        closesocket(sock);
        sock = INVALID_SOCKET;
    }
    //Convert vector to array
    char* buffer = packet.data();

    //Send packet length C->S
    std::vector<char> packetLength;
    writeInt(&packetLength, packet.size());
    send(sock, packetLength.data(), (int) strlen(packetLength.data()), 0);

    //Write packet to connection C->S
    n = send(sock, buffer, (int) strlen(buffer), 0);

    //Test if the packet sent successfully
    if (n < 0) {
        Util::loopPrint("Failed to send packet to " + address->getString());
        printf("Client: send() error %ld.\n", WSAGetLastError());
        return;
    }

    //Send status request packet C->S
    char endBytes[1] = {0x01};
    send(sock, endBytes, (int) strlen(endBytes), 0);
    endBytes[0] = 0x00;
    send(sock, endBytes, (int) strlen(endBytes), 0);


    char buf[6000];
    recv(sock, buf, 6000, MSG_PEEK);
    for (char &c : buf) {
        Util::loopPrint(std::to_string(c));
    }

    int size = readVarInt(&sock, address);
    Util::loopPrint(std::to_string(size));
    int packetId = readVarInt(&sock, address);

    if (packetId == -1) {
        Util::loopPrint("Invalid packet id of -1 at ip " + address->getString());
        return;
    }
    if (packetId != 0x00) {
        Util::loopPrint("Invalid response packet was given at " + address->getString());
        return;
    }

    int length = readVarInt(&sock, address);

    if (length < 1) {
        Util::loopPrint("Invalid packet length for ip " + address->getString() + " length :" + std::to_string(length));
        return;
    }

    char* inBuf = new char[length];
    n = recv(sock, inBuf, length, 0);
    if (n < 0) {
        Util::loopPrint("Error fully reading packet at " + address->getString());
        return;
    }

    if(shutdown(sock, SD_SEND) != 0)
        printf("Client: Well, there is something wrong with the shutdown(). The error code: %ld\n", WSAGetLastError());


    std::string str(inBuf);
    delete [] inBuf;
    Util::loopPrint("Result buffer " + str);
    closesocket(sock);
}
