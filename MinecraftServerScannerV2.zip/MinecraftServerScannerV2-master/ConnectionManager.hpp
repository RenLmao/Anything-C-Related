//
// Created by Hypericats on 2/21/2024.
//

#pragma comment(lib, "Ws2_32.lib")

#ifndef MINECRAFTSERVERSCANNER_CONNECTIONMANAGER_HPP
#define MINECRAFTSERVERSCANNER_CONNECTIONMANAGER_HPP

#include <iostream>
#include <vector>

//socket for windows
#include <winsock2.h>
#include <ws2tcpip.h>

//networking
#include <cstdio>
#include <cstring>

#include "Util.hpp"
#include "ipAddress.hpp"

class ConnectionManager {
private:
    ipAddress* address;
    unsigned short port;
    static void writeInt(std::vector<char> *packet, unsigned int i);
    static void writeShort(std::vector<char> *packet, unsigned short i);
    static void writeString(std::vector<char> *packet, std::basic_string<char> str);
    static int readVarInt(const SOCKET* socket, ipAddress *address);
public:
    explicit ConnectionManager(ipAddress *address, unsigned short port);
    void ping(std::vector<char> packet);
    std::vector<char> getHandshakePacket();
};


#endif //MINECRAFTSERVERSCANNER_CONNECTIONMANAGER_HPP
