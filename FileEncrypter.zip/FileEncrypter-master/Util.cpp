//
// Created by Hypericats on 2/18/2024.
//

#include "Util.h"

void Util::print(const std::string& str) {
    std::cout << str << std::endl;
}

void Util::quickPrint(const std::string& str) {
    std::cout << str << "\n";
}