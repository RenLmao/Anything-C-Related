//
// Created by Hypericats on 2/18/2024.
//

#include <string>
#include <iostream>

#ifndef FILEENCRYPTER_UTIL_H
#define FILEENCRYPTER_UTIL_H


class Util {
public:
    static void print(const std::string& str);
    static void quickPrint(const std::string& str);
};


#endif //FILEENCRYPTER_UTIL_H
